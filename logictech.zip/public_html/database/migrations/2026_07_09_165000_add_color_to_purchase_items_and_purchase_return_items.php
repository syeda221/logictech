<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('purchase_items', function (Blueprint $table) {
            $table->text('color')->nullable()->after('product_id');
        });

        Schema::table('purchase_return_items', function (Blueprint $table) {
            $table->text('color')->nullable()->after('product_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('purchase_items', function (Blueprint $table) {
            $table->dropColumn('color');
        });

        Schema::table('purchase_return_items', function (Blueprint $table) {
            $table->dropColumn('color');
        });
    }
};
