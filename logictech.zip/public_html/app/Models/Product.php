<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Product extends Model
{
    use HasFactory, SoftDeletes;

    protected $guarded = [];

    // protected $fillable = [
    //     'creater_id', 'category_id', 'sub_category_id', 'item_code', 'item_name', 'size',
    //     'opening_carton_quantity', 'carton_quantity', 'loose_pieces', 'pcs_in_carton',
    //     'wholesale_price', 'retail_price', 'initial_stock', 'alert_quantity'
    // ];
    // app/Models/Product.php
    public function warehouses()
    {
        return $this->belongsToMany(Warehouse::class, 'warehouse_stocks', 'product_id', 'warehouse_id')
            ->withPivot('quantity', 'price', 'remarks');
    }

    // app/Models/Product.php

    public function activeDiscount()
    {
        return $this->hasOne(ProductDiscount::class, 'product_id')
            ->where('status', 1); // only active discount
    }

    public function category_relation()
    {
        return $this->belongsTo(Category::class, 'category_id');
    }

    public function sub_category_relation()
    {
        return $this->belongsTo(Subcategory::class, 'sub_category_id');
    }

    public function unit()
    {
        return $this->belongsTo(Unit::class, 'unit_id');
    }

    public function brand()
    {
        return $this->belongsTo(Brand::class, 'brand_id');
    }

    public function stock()
    {
        return $this->hasOne(Stock::class);
    }

    public function warehouseStocks()
    {
        return $this->hasMany(\App\Models\WarehouseStock::class);
    }

    public function movements()
    {
        return $this->hasMany(StockMovement::class);
    }

    public function scopeWithAvailable($q)
    {
        return $q->withSum('movements as available_qty', 'qty'); // sum of ledger
    }

    public function webImages()
    {
        return $this->hasMany(ProductWebImage::class)->orderBy('sort_order', 'asc');
    }

    protected static function booted()
    {
        static::saved(function ($product) {
            if ($product->item_type !== self::TYPE_FINISH_GOODS && !is_null($product->alert_quantity)) {
                $totalPieces = \App\Models\WarehouseStock::where('product_id', $product->id)->sum('total_pieces');
                if ($totalPieces < $product->alert_quantity) {
                    \App\Models\SystemNotification::createStockAlertNotification($product, $totalPieces);
                }
            }
        });
    }

    const TYPE_RAW_MATERIAL = 'raw_material';
    const TYPE_FINISH_GOODS  = 'finish_goods';
    const TYPE_BOTH          = 'both';

    public function isRawMaterial(): bool
    {
        return $this->item_type === self::TYPE_RAW_MATERIAL || $this->item_type === self::TYPE_BOTH;
    }

    public function isFinishGoods(): bool
    {
        return $this->item_type === self::TYPE_FINISH_GOODS || $this->item_type === self::TYPE_BOTH;
    }

    public function isBoth(): bool
    {
        return $this->item_type === self::TYPE_BOTH;
    }

    public function getItemTypeBadgeAttribute(): string
    {
        return match($this->item_type) {
            'raw_material' => '<span class="badge" style="background:#fef3c7;color:#92400e;border:1px solid #fde68a;font-weight:600;"><i class="fas fa-boxes-stacked me-1"></i>Raw Material</span>',
            'finish_goods' => '<span class="badge" style="background:#ecfdf5;color:#065f46;border:1px solid #a7f3d0;font-weight:600;"><i class="fas fa-microchip me-1"></i>Finished Goods</span>',
            default        => '<span class="badge" style="background:#eef2ff;color:#3730a3;border:1px solid #c7d2fe;font-weight:600;"><i class="fas fa-layer-group me-1"></i>Both</span>',
        };
    }

    public function getNameAttribute()
    {
        return $this->item_name;
    }
}
